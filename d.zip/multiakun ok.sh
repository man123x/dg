#!/bin/bash
clear
echo "\033[1;31m    Multi Akun "
echo "\033[1;31m    Bersiaplah kita  akan mulai  "
sleep 2s

python3 telemaxv7.3.6.py +6283172161365 doge
python3 telemaxv7.3.6.py +6283890795061 doge
python3 telemaxv7.3.6.py +6283804684808 doge
python3 telemaxv7.3.6.py +6283808827473 doge
python3 telemaxv7.3.6.py +6283892599762 doge
python3 telemaxv7.3.6.py +6283172161369 doge
python3 telemaxv7.3.6.py +6283892599802 doge
python3 telemaxv7.3.6.py +6283890795145 doge
python3 telemaxv7.3.6.py +6283165366213 doge
python3 telemaxv7.3.6.py +6283177680219 doge
python3 telemaxv7.3.6.py +6283193334588 doge
python3 telemaxv7.3.6.py +6283808827490 doge
python3 telemaxv7.3.6.py +6283808827482 doge
python3 telemaxv7.3.6.py +6283197568096 doge
python3 telemaxv7.3.6.py +6283193334585 doge
python3 telemaxv7.3.6.py +6283804684814 doge
python3 telemaxv7.3.6.py +6283177680229 doge
python3 telemaxv7.3.6.py +6283147121940 doge
python3 telemaxv7.3.6.py +6283807003917 doge
python3 telemaxv7.3.6.py +6283147121976 doge
python3 telemaxv7.3.6.py +6283165366218 doge
python3 telemaxv7.3.6.py +6283879369903 doge
python3 telemaxv7.3.6.py +6283172161323 doge
python3 telemaxv7.3.6.py +6283807776350 doge
python3 telemaxv7.3.6.py +6283165366243 doge
python3 telemaxv7.3.6.py +6283892599793 doge
python3 telemaxv7.3.6.py +6283166089529 doge
python3 telemaxv7.3.6.py +6283165366228 doge
python3 telemaxv7.3.6.py +6283181867288 doge
python3 telemaxv7.3.6.py +6283892599761 doge
python3 telemaxv7.3.6.py +6283197568066 doge
python3 telemaxv7.3.6.py +6283879369936 doge
python3 telemaxv7.3.6.py +6283181867311 doge
python3 telemaxv7.3.6.py +6283181867315 doge
python3 telemaxv7.3.6.py +6283890574042 doge
python3 telemaxv7.3.6.py +6283147121949 doge
python3 telemaxv7.3.6.py +6283892599768 doge
python3 telemaxv7.3.6.py +6283892599778 doge
python3 telemaxv7.3.6.py +6283807776474 doge
python3 telemaxv7.3.6.py +6283147121982 doge
python3 telemaxv7.3.6.py +6283199437225 doge
python3 telemaxv7.3.6.py +6283807776430 doge

x=12000
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \033[1;36m [ 1 ] ke 1 akun lagi sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done
sh run.sh
done