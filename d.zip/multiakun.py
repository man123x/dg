format='python3' # jika di vps pakai python3
nama_script='telemaxv7.3.6.py' # sesuaikan nama script
currency='doge' # jenis currency yang ingin di japankan
jumlah_akun=0 #jumlah akun per jeda jangan terlalu banyak agar perangkat tidak panas terutama jika ram kecil
jeda_perakun=3500 # hitungan detik
jeda_reload_ke_awal=100 # hitungan detik
kembali_ke='sh run.sh'

# bagian bawah ini tidak perlu di edit
###
import os
from time import *
if os.path.exists('multiakun.sh'):os.remove('multiakun.sh')
if os.path.exists('multi.txt'):os.remove('multi.txt')
o=0
ar = os.listdir('session/')
for phone in ar:
    if phone.endswith(".session-journal"):
        os.remove('session/'+phone)
    else:
        nomor = phone.replace('.session','')
        try:
            o+=1
            print(f'[{str(o)}]'+nomor)
            with open('multi.txt','a+') as mu:
                mu.write(nomor+'\n')
        except Exception as e:
            print(e)
merah='\\033[1;31m'
cyan='\\033[1;36m'
insert = f"""
x={jeda_perakun}
while [ $x -gt 0 ]
do
sleep 20s
clear
echo "{cyan}"""
insert2=f"""ke {jumlah_akun} akun lagi sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done

"""
bottom = f"""
x={jeda_reload_ke_awal}
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \\033[1;36m lanjut ke Multi  clickbot sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done
sh run.sh
done"""
head = f"""#!/bin/bash
clear
echo "{merah}    Multi Akun "
echo "{merah}    Bersiaplah kita  akan mulai  "
sleep 2s

"""
neo= open("multi.txt","r")
grp=neo.read().splitlines()
ju=len(grp)
print(f'\n\ntotal akun : {ju}')
with open('multiakun.sh','a+') as mau:
    mau.write(head)
ur=0
i=0
k=0
nom=0
kadal=jumlah_akun-1
sleep(2)
for i in range(ju):
    k+=1
    try:
        dia=grp[i]
        if(ur==kadal):
            with open('multiakun.sh','a+') as mau:
                mau.write(f'{format} {nama_script} {dia} {currency}\n')
                ur+=1
        else:
            if(ju==k):
                with open('multiakun.sh','a+') as mau:
                    mau.write(f'{format} {nama_script} {dia} {currency}\n')
                    ur+=1
            else:
                with open('multiakun.sh','a+') as mau:
                    mau.write(f'{format} {nama_script} {dia} {currency} &\n')
                    ur+=1  
    except Exception as e:
        print(e)
        pass
    if (ur==jumlah_akun):
        if (k==ju):
           pass
        else:
           nom+=1
           with open('multiakun.sh','a+') as mau:
               mau.write(f'{insert} [ {str(nom)} ] {insert2}')
           ur=0
with open('multiakun.sh','a+') as mau:
    mau.write(bottom)
    mau.close()
os.remove('multi.txt')
exit()


