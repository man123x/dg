python3 multiakun.py
sh multiakun.sh