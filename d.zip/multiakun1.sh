#!/bin/bash
clear
echo "\033[1;31m    Multi Akun "
echo "\033[1;31m    Bersiaplah kita  akan mulai  "
sleep 2s

python3 telemaxv7.3.6.py +6283181867293 doge

x=70
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \033[1;36m lanjut ke Multi  clickbot sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done

python3 telemaxv7.3.6.py +6283176241468 doge

x=70
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \033[1;36m [ 1 ] ke 1 akun lagi sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done

python3 telemaxv7.3.6.py +6283199437270 doge

x=12000
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \033[1;36m [ 1 ] ke 1 akun lagi sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done
sh run.sh
done